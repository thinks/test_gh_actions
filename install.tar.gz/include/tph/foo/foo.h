#pragma once

namespace tph {

int FooFunc(const char* str);

} // namespace tph
