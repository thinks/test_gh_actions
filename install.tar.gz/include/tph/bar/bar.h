#pragma once

namespace tph {

int BarFunc(const char* str);

} // namespace tph
